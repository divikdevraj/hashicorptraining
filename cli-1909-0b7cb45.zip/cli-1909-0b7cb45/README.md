# Instruqt CLI

This repository contains the releases of the Instruqt commandline interface.
